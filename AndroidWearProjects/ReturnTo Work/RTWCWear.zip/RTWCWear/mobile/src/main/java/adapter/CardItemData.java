package adapter;

public class CardItemData {
    private String m_text1;
    private String m_text2;

    public String getText1() {
        return m_text1;
    }

    public void setText1(String text1) {
        m_text1 = text1;
    }

    public String getText2() {
        return m_text2;
    }

    public void setText2(String text1) {
        m_text2 = text1;
    }


}
